from django.urls import path
from . import views
urlpatterns = [
    path('',views.home),
    path('about/', views.about),
    path('test/', views.test),
    path('contacts/', views.contacts)
]